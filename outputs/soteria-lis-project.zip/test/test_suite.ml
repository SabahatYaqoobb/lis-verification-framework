open Syntax

let p ?(apis=[]) ?(bound=8) body = {body; apis; loop_bound=bound}
let check_verified name pre program post = match Verifier.verify_program pre program post with
  | Verifier.Verified _ -> () | _ -> failwith (name ^ " should verify")
let check_bug name pre program post = match Verifier.find_bug_program pre program post with
  | Some _ -> () | None -> failwith (name ^ " should have a counterexample")

let () =
  check_verified "assignment" True (p (Assign("x",Int 1))) (Var "x" =: Int 1);
  check_verified "store/load" True (p (Seq[Store(Int 3,Int 9);Assign("x",Load(Int 3))])) (Var "x" =: Int 9);
  check_bug "bad assignment" True (p (Assign("x",Int 1))) (Var "x" =: Int 2);
  check_bug "zero abs" True
    (p (If(Var "x" >: Int 0,Assign("y",Var "x"),Assign("y",Neg(Var "x")))))
    (Var "y" >: Int 0);
  print_endline "All tests passed."
